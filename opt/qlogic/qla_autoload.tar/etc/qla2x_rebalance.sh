#!/usr/bin/bash

irqset()
{
	echo Setting IRQ $2 to mask $1
	echo $1 > /proc/irq/$2/smp_affinity
	if [ $? -ne 0 ] ; then
		echo 1 > /proc/irq/$2/smp_affinity
		C=1
	fi
}

C=1
CX=2

for irq in `cat /proc/interrupts | grep qla2xxx | awk -F: '{print $1}'`
do
	irqset $CX $irq
	C=`expr $C \* 4`
	CX=`printf "%x" $C`
done
